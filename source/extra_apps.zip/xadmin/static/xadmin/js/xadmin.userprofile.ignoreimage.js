$(document).ready(function(){
    $('#id_image').removeAttr('required')
    $('label[for=id_image]').find('span').remove()
})
